===============================================================================================================================================================================
	ALTERED SHORT CIRCUIT EFFECTS [v1.1]
	by Skeleton Hotel
===============================================================================================================================================================================
	UPDATE CHANGELOG
===============================================================================================================================================================================
~~~~~~~~~~~~~~~
	v1.1
~~~~~~~~~~~~~~~
	� Fixed broken materials caused by the June 22, 2021 update.


===============================================================================================================================================================================
	OVERVIEW
===============================================================================================================================================================================

	This mod includes two different versions, each contained in its own VPKs
	
	1. "Altered ShC FX.vpk"
		� The standard version of the mod.
		� Includes new particle effects for both the Short Circuit's primary fire and the lightning ball secondary fire.
	
	2. "Altered ShC FX + Hacky Spark Removal.vpk"
		� Includes all the stuff in the standard version, PLUS a really hacky, buggy """fix""" that removes the generic spark effect that spawns every time the
			Short Circuit's lightning ball hits a player or projectile.
			� I say "buggy" b/c this will ALSO inadvertently remove some similar spark effects! Examples being the sparks of the default metal bullet impact effect,
				the sparks emitted by the disintegration effect for the Cow Mangler/Righteous Bison/Short Circuit, etc. See the README included in the download for more info.
		� DON'T USE THIS unless you're alright with the consequences described above!!
		� See the EXTRA INFO section below (at the bottom of this text file) if you want to know more about this spark removal and why it's so busted.


===============================================================================================================================================================================
	POTENTIAL COMPATIBILITY ISSUES
===============================================================================================================================================================================

	This mod replaces the particle file dxhr_fx.pcf, which contains various particle effects used by the Short Circuit, Machina, etc.
		Thus, other mods that replace the same PCF file (such as a mod that changes the Machina�s tracer effect) will be incompatible with this one.


===============================================================================================================================================================================
    INSTALLATION
===============================================================================================================================================================================

	Paste the VPK of your choice (the standard version of the mod, or the version that includes the hacky spark removal) into your �custom� folder in your TF2 directory.
		You only need to install one VPK or the other, not both.
		
		
===============================================================================================================================================================================
	EXTRA INFO: Why the need for the hacky spark removal?
===============================================================================================================================================================================

	A long, technical explanation for anyone curious:

	The generic spark effect (emitted by the lightning ball on contact with a player/projectile) is, for some reason, NOT included within the Short Circuit's own particle systems.
		Rather, this spark effect seems to be borrowed from another, pre-existing particle system. Thus, it can't be removed by editing dxhr_fx.pcf (the file that otherwise
		contains most of the Short Circuit's particles).
		
	I scoured a bunch of other PCF files to try to locate this generic spark effect, but had no success. I suspect the effect might be hard-coded into the engine, as it resembles
		similar default spark effects found in various Source games.
		
	So, since I couldn't edit/remove the spark particle effect itself, I did the next best thing: I edited the VMT file of the spark texture used by said effect so the texture
		would simply not render in-game.
	
	While the above change TECHNICALLY works, there's a side-effect: MANY OTHER particle effects ALSO use that same spark texture! So the change effectively removes the sparks
		from THOSE effects as well!
		
	If you have the technical knowledge and know of a better potential solution for removing that damn spark effect (with less adverse side-effects), I encourage you to contact me
		on Gamebanana, please!
		
		� Skeleton Hotel

